// public/js/scripts.js

// Example of client-side validation
document.querySelector('form').addEventListener('submit', function(event) {
    const marksInput = document.getElementById('marks');
    const marks = marksInput.value.trim();
    
    if (isNaN(marks) || parseFloat(marks) < 0 || parseFloat(marks) > 100) {
        marksInput.classList.add('is-invalid');
        event.preventDefault();
    } else {
        marksInput.classList.remove('is-invalid');
    }
});
