const express = require('express');
const bodyParser = require('body-parser');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const app = express();
app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const db = new sqlite3.Database('./database.db');

// Initialize the database
db.serialize(() => {
    db.run('CREATE TABLE IF NOT EXISTS results (student_id TEXT, subject TEXT, marks REAL, grade_point REAL)');
    db.run('CREATE TABLE IF NOT EXISTS recheck_requests (student_id TEXT)');
});

app.get('/', (req, res) => {
    res.render('home');
});

app.get('/teacher-login', (req, res) => {
    res.render('teacher_login');
});

app.post('/teacher-login', (req, res) => {
    const { username, password } = req.body;
    if (username === 'teacher' && password === 'password') {
        res.redirect('/teacher-dashboard');
    } else {
        res.render('teacher_login', { error: 'Invalid username or password' });
    }
});

app.get('/teacher-dashboard', (req, res) => {
    res.render('teacher_dashboard');
});

app.post('/teacher-dashboard', (req, res) => {
    const { student_id, subject_names, subject_marks } = req.body;
    let totalGradePoints = 0;
    subject_names.forEach((subject, index) => {
        const mark = parseFloat(subject_marks[index]);
        const gradePoint = calculateGradePoint(mark);
        totalGradePoints += gradePoint;
        db.run('INSERT INTO results (student_id, subject, marks, grade_point) VALUES (?, ?, ?, ?)', [student_id, subject, mark, gradePoint], (err) => {
            if (err) {
                return console.error(err.message);
            }
        });
    });

    res.redirect('/teacher-dashboard');
});

app.post('/calculate-cgpa', (req, res) => {
    const { student_id, subjects, marks } = req.body;
    const subjectsArray = subjects.split(',');
    const marksArray = marks.split(',');

    let totalGradePoints = 0;
    let results = [];

    subjectsArray.forEach((subject, index) => {
        const mark = parseFloat(marksArray[index]);
        const gradePoint = calculateGradePoint(mark);
        totalGradePoints += gradePoint;

        results.push({ student_id, subject, marks: mark, grade_point: gradePoint });

        db.run('INSERT INTO results (student_id, subject, marks, grade_point) VALUES (?, ?, ?, ?)', [student_id, subject, mark, gradePoint], (err) => {
            if (err) {
                return console.error(err.message);
            }
        });
    });

    const cgpa = totalGradePoints / subjectsArray.length;

    res.json({ cgpa, results });
});

app.get('/student-result', (req, res) => {
    res.render('student_result');
});

app.post('/student-result', (req, res) => {
    const student_id = req.body.student_id.toLowerCase();
    db.all('SELECT subject, marks, grade_point FROM results WHERE LOWER(student_id) = ?', [student_id], (err, rows) => {
        if (err) {
            return console.error(err.message);
        }
        const cgpa = rows.length ? (rows.reduce((sum, row) => sum + row.grade_point, 0) / rows.length) : 'No result found';
        res.render('student_result', { results: rows, cgpa, student_id });
    });
});

app.post('/recheck-request', (req, res) => {
    const student_id = req.body.student_id;
    db.run('INSERT INTO recheck_requests (student_id) VALUES (?)', [student_id], (err) => {
        if (err) {
            return console.error(err.message);
        }
        res.redirect('/student-result');
    });
});

function calculateGradePoint(marks) {
    if (marks >= 80) return 4.0;
    if (marks >= 70) return 3.5;
    if (marks >= 60) return 3.0;
    if (marks >= 50) return 2.5;
    if (marks >= 40) return 2.0;
    if (marks >= 33) return 1.0;
    return 0.0;
}

app.listen(3000, () => {
    console.log('Server is running on http://localhost:3000');
});
